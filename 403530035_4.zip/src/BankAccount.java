

import java.util.ArrayList; 

public class BankAccount {
    String state;
    int accountNumber;
    private double balance;
    private ArrayList<Double> TransactionList = null;
    
    public BankAccount(){
        this(-1,-1);
    }
    
    public BankAccount(int anAccountNumber){
        this(anAccountNumber, 0);
    }
    
    public BankAccount(int anAccountNumber, double initialBalance){
        this.state = "open";
        this.accountNumber = anAccountNumber;
        this.balance = initialBalance;
        this.TransactionList = new ArrayList<Double>();
    }
    
    //isOpen()開啟狀態函式
    
    private boolean isOpen(){
        return this.state.equalsIgnoreCase("open");
    }
    
    //isSuspend()凍結狀態函式
    
    private boolean isSuspend(){
        return this.state.equalsIgnoreCase("suspend");
    }
    
    //isClosed()關閉狀態函式
    
    private boolean isClosed(){
        return this.state.equalsIgnoreCase("closed");
    }
    
    // reOpen() 重新開啟帳戶狀態
    
    void reOpen(){
        this.state = "open";
    }
    
    //suspend() 暫停模式
    
    void suspend(){
        this.state = "suspend";
    }
    
    //close() 關閉帳戶
    
    void close(){
        this.state = "closed";
    }
    
    
    //deposit 存錢函式
    
    void deposit(double amount){
        if(!isOpen() || amount < 0){
        	
        }else{
            this.balance = this.balance + amount;
            addTransaction(amount);
        }
    }
    
    // withdraw()提錢函式
    
    void withdraw(double amount){
        if(!isOpen() || amount < 0 || amount > this.balance){
            //System.out.println("有錯誤的地方");
        }else{
            this.balance = this.balance - amount;
            addTransaction(0 - amount);
        }            
    }
    
    //addTransaction() 新增交易記錄函式
    void addTransaction(double amount){
        this.TransactionList.add(amount);
    }
    
    //getTranscations() 取得交易紀錄函式
    
    String getTransactions(){
        String rlt = "";
        for(int i = 0 ; i < this.TransactionList.size() ; i++){
            rlt = rlt + (i+1)+ ": " +this.TransactionList.get(i)+"\n";
        }
        return rlt;
    }

    //getBalance() 取得帳戶餘額函式
    
    double getBalance(){
        return this.balance;
    }
    
    //retrieveNumberOfTransactions() 取得交易次數
    
    int retrieveNumberOfTransactions(){
        return this.TransactionList.size();
    }
}

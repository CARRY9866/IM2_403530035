

public class BankTester {

	public static void main(String[] args) {
		Bank studentBank = new Bank(); // new 一個 叫做studentBank 的物件 Bank 並給他記憶體位址

		// Account #1001 transactions: Basic Test
		studentBank.addAccount(1001, 0);
		studentBank.deposit(1001, 500);
		studentBank.deposit(1001, 300);
		studentBank.deposit(1001, 50);
		studentBank.withdraw(1001, 500);
		studentBank.withdraw(1001, 350);
		studentBank.closeAccount(1001);
		
		//Account #1002 transactions: Basic Test
		
		studentBank.addAccount(1002, 0);
		studentBank.deposit(1002, 2500);
		studentBank.deposit(1002, 1500);
		studentBank.withdraw(1002, 2000);
		studentBank.withdraw(1002, 500);
		studentBank.deposit(1002, 4000);
		studentBank.suspendAccount(1002);

		//Account #1003 transactions: Basic Test
		
		studentBank.addAccount(1003, 0);
		studentBank.deposit(1003, 1000);
		studentBank.deposit(1003, 100);
		studentBank.withdraw(1003, 250);
		studentBank.deposit(1003, 750);
		studentBank.withdraw(1003, 1600);
		studentBank.closeAccount(1003);

		
		//將顯示結果 Account #1001列出乃
		System.out.println(studentBank.summarizeAccountTransactions(1001)); 
		
		//將顯示結果 Account #1002列出乃
		System.out.println(studentBank.summarizeAccountTransactions(1002));
		
		//將顯示結果 Account #1003列出乃
		System.out.println(studentBank.summarizeAccountTransactions(1003)); 
		
		//列出總處理紀錄
		System.out.println(studentBank.summarizeAllAccounts()); 
	}
}